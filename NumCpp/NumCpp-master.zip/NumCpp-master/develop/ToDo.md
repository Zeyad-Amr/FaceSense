# TODO

## Version 2.11.0

* run clang-tidy
* run cppcheck
* rebuild documentation
* merge to main / tag / create release
