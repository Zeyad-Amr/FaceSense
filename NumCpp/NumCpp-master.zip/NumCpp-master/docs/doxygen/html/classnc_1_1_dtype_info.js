var classnc_1_1_dtype_info =
[
    [ "bits", "classnc_1_1_dtype_info.html#a3f6aa0cc80e59dc331bc0e8dfe2f20bb", null ],
    [ "epsilon", "classnc_1_1_dtype_info.html#a845cc6986a3912805ab68960bc2b2318", null ],
    [ "isInteger", "classnc_1_1_dtype_info.html#a10b60bd27123b5c724e2a52526fe8cfe", null ],
    [ "isSigned", "classnc_1_1_dtype_info.html#a039ecfb9a5bd9fe0cb751a59f28055d1", null ],
    [ "max", "classnc_1_1_dtype_info.html#a2a3dc0ba2812411660219f61189d8aca", null ],
    [ "min", "classnc_1_1_dtype_info.html#ab566f68bc6b82c06b5a3df887f87ab74", null ]
];