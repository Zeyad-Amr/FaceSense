var arctan2_8hpp =
[
    [ "arctan2", "arctan2_8hpp.html#a3d3c4c6b273e6eee45cf6359cf621980", null ],
    [ "arctan2", "arctan2_8hpp.html#abdec674ddb32540775e97e0fca6016aa", null ]
];