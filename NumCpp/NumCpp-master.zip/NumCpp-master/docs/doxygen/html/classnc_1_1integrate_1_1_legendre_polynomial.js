var classnc_1_1integrate_1_1_legendre_polynomial =
[
    [ "LegendrePolynomial", "classnc_1_1integrate_1_1_legendre_polynomial.html#a2e1fefae138e66215cd7586a85fc3642", null ],
    [ "getRoot", "classnc_1_1integrate_1_1_legendre_polynomial.html#ac2d8f6377f8ae7cf27b4d0599eb7880b", null ],
    [ "getWeight", "classnc_1_1integrate_1_1_legendre_polynomial.html#ac6b804e8a2d582df601cc2b3ff2bf74f", null ]
];