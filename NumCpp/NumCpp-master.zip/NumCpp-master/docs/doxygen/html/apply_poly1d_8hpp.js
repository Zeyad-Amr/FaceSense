var apply_poly1d_8hpp =
[
    [ "applyPoly1d", "apply_poly1d_8hpp.html#a52f3be5bbad0243643027a1477662356", null ]
];