var choice_8hpp =
[
    [ "choice", "choice_8hpp.html#ad60ec32743642bd0540fec0076043fed", null ],
    [ "choice", "choice_8hpp.html#a7fcf28e4b1a2b015b1099986c5202877", null ],
    [ "choice", "choice_8hpp.html#a036516a94f10c22896e6cd34cc9077e9", null ],
    [ "choice", "choice_8hpp.html#a997b3d3405e4f6dd06399c148ae33090", null ]
];