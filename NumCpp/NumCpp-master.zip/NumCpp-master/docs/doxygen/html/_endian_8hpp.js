var _endian_8hpp =
[
    [ "byteSwap", "_endian_8hpp.html#a28d96487f9ac66755e2dd4925a459e0d", null ],
    [ "isLittleEndian", "_endian_8hpp.html#a11907ef8078650aee8fe900854ba5bb4", null ]
];