var bernoulli_8hpp =
[
    [ "bernoilli", "bernoulli_8hpp.html#a59caf35b816a219aa2782dd45df207ca", null ],
    [ "bernoilli", "bernoulli_8hpp.html#a1af26e52a24fca2b572605ec4b2c1f1b", null ]
];