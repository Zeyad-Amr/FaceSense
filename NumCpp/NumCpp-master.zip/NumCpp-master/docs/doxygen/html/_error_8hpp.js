var _error_8hpp =
[
    [ "THROW_INVALID_ARGUMENT_ERROR", "_error_8hpp.html#af2aff1172060367b9c5398fa097fa8fd", null ],
    [ "THROW_RUNTIME_ERROR", "_error_8hpp.html#a0f0ce4acf1fd6032112a06ebc50bb05a", null ],
    [ "throwError", "_error_8hpp.html#ae23be92f797ad9d90604456bdf27092f", null ]
];