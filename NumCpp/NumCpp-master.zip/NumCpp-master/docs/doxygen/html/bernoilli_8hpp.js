var bernoilli_8hpp =
[
    [ "bernoulli", "bernoilli_8hpp.html#a8d4a1a62fc03a44cccfa4012413bd70f", null ],
    [ "bernoulli", "bernoilli_8hpp.html#a1a5af4283601fd8663dcdc34599aede3", null ]
];